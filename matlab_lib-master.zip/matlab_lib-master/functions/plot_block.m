function [handle] = plot_block(H, size2, color, alpha, linestyle)
    % Define vertices for each face of the block
    vertices = [ ...
        [1 1 1 1]*size2(1)/2, -[1 1 1 1]*size2(1)/2; ...
        [-1 1 1 -1]*size2(2)/2, [-1 1 1 -1]*size2(2)/2; ...
        [1 1 -1 -1]*size2(3)/2, [1 1 -1 -1]*size2(3)/2 ...
    ];
    
    % Define the faces of the block (each face is a set of 4 vertices)
    faces = [ ...
        1 2 3 4; % face1
        5 6 7 8; % face2
        1 5 6 2; % face3
        3 7 8 4; % face4
        1 5 8 4; % face5
        2 6 7 3  % face6
    ];
    
    % Transform vertices using the homogeneous matrix H
    num_vertices = size(vertices, 2);
    homogeneous_vertices = [vertices; ones(1, num_vertices)];
    transformed_vertices = H * homogeneous_vertices; % Perform matrix multiplication
    transformed_vertices = transformed_vertices(1:3, :); % Extract the first 3 rows
    
    % Initialize handles for the patches
    handle = gobjects(1, 6); % Preallocate handle array
    
    % Create the patch objects for each face
    for i = 1:6
        % Extract the vertex indices for the current face
        face_indices = faces(i, :);
        
        % Extract the coordinates for the current face
        x_data = transformed_vertices(1, face_indices);
        y_data = transformed_vertices(2, face_indices);
        z_data = transformed_vertices(3, face_indices);
        
        % Create the patch object for the face
        handle(i) = patch(x_data, y_data, z_data, color, ...
            'FaceAlpha', alpha, 'EdgeColor', 'none', 'LineStyle', linestyle);
    end
end
