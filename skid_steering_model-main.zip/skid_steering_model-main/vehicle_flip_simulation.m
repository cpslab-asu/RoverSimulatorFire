function vehicle_flip_simulation(turn_angle_deg, velocity)
    % Parameters
    m = 1500; % mass of the vehicle (kg)
    g = 9.81; % gravitational acceleration (m/s^2)
    h = 0.5; % height of the center of mass (m)
    w = 1.6; % track width of the vehicle (m)
    L = 2.5; % wheelbase of the vehicle (m)
    I_x = 850000; % moment of inertia about x-axis (roll inertia) (kg.m^2)
    C_alpha = 80000; % cornering stiffness of tires (N/rad)
    
    % Convert inputs
    turn_angle_rad = deg2rad(turn_angle_deg); % turn angle in radians
    
    % Simulation time parameters
    t_final = 5; % total simulation time (seconds)
    dt = 0.01; % time step (seconds)
    t = 0:dt:t_final; % time vector
    
    % State variables initialization
    v_x = velocity; % longitudinal velocity (constant for this simulation)
    v_y = 0; % initial lateral velocity (m/s)
    omega_z = 0; % initial yaw rate (rad/s)
    roll_angle = 0; % initial roll angle (rad)
    omega_roll = 0; % initial roll rate (rad/s)
    
    % Arrays for storing results
    roll_angles = zeros(size(t));
    lat_accels = zeros(size(t));
    
    % Simulation loop
    for i = 1:length(t)
        % Lateral force using simple cornering stiffness model
        F_y = C_alpha * turn_angle_rad;
        
        % Lateral acceleration
        lat_accel = F_y / m;
        lat_accels(i) = lat_accel;
        
        % Roll moment due to lateral acceleration
        roll_moment = h * F_y;
        
        % Roll dynamics
        omega_roll = omega_roll + (roll_moment / I_x) * dt;
        roll_angle = roll_angle + omega_roll * dt;
        roll_angles(i) = roll_angle;
        
        % Check for flip condition: when the roll angle exceeds a threshold
        if abs(roll_angle) > atan(w / (2 * h))
            disp('Vehicle flips due to high roll angle!');
            break;
        end
    end
    
    % Plot results
    figure;
    subplot(2, 1, 1);
    plot(t, rad2deg(roll_angles));
    xlabel('Time (s)');
    ylabel('Roll Angle (deg)');
    title('Roll Angle vs Time');
    
    subplot(2, 1, 2);
    plot(t, lat_accels);
    xlabel('Time (s)');
    ylabel('Lateral Acceleration (m/s^2)');
    title('Lateral Acceleration vs Time');
    
    % Display final state
    if abs(roll_angle) <= atan(w / (2 * h))
        disp('Vehicle does not flip.');
    end
end
