function h = plot_wheel(H, radius, width, color,linestyle)
    [X, Y, Z] = cylinder(radius);
    Z = Z * width - width / 2;  % Adjust cylinder height
    %h = surf(H(1,1) * X + H(1,4), H(2,1) * Y + H(2,4), H(3,1) * Z + H(3,4));
    h = patch(H(1,1) * X + H(1,4), H(2,1) * Y + H(2,4), H(3,1) * Z + H(3,4), color, ...
            'EdgeColor', 'none', 'LineStyle', linestyle);
    
end