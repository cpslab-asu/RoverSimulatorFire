function vehicle_flip_simulation_with_visualization(turn_angle_deg, velocity)
    % Parameters
    m = 1500; % mass of the vehicle (kg)
    g = 9.81; % gravitational acceleration (m/s^2)
    h = 0.5; % height of the center of mass (m)
    w = 1.6; % track width of the vehicle (m)
    L = 2.5; % wheelbase of the vehicle (m)
    I_x = 850; % moment of inertia about x-axis (roll inertia) (kg.m^2)
    C_alpha = 80000; % cornering stiffness of tires (N/rad)
    
    % Convert inputs
    turn_angle_rad = deg2rad(turn_angle_deg); % turn angle in radians
    
    % Simulation time parameters
    t_final = 10; % total simulation time (seconds)
    dt = 0.05; % time step (seconds)
    t = 0:dt:t_final; % time vector
    
    % Path parameters
    radius = 20; % Radius of the turn (m)
    angular_velocity = velocity / radius; % Angular velocity (rad/s)
    
    % State variables initialization
    omega_roll = 0; % initial roll rate (rad/s)
    roll_angle = 0; % initial roll angle (rad)
    
    % Arrays for storing results
    roll_angles = zeros(size(t));
    lat_accels = zeros(size(t));
    
    % Create a figure for the 3D visualization
    figure;
    car_plot = create_car_plot(w, L, h);
    
    % Initialize position on the circular path
    car_position = [radius, 0]; % Initial position at (radius, 0)
    car_angle = 0; % Initial angle (0 rad)
    
    % Set axis limits to prevent the car from disappearing
    axis_limits = [-25 25 -25 25 -2 2]; % Adjust limits based on path and vehicle size
    axis(axis_limits); 
    grid on;
    
    % Simulation loop
    for i = 1:length(t)
        % Update car position along circular path
        car_angle = car_angle + angular_velocity * dt; % Update angle
        car_position = [radius * cos(car_angle), radius * sin(car_angle)]; % Update position based on angle
        
        % Lateral force using simple cornering stiffness model
        F_y = C_alpha * turn_angle_rad;
        
        % Lateral acceleration
        lat_accel = F_y / m;
        lat_accels(i) = lat_accel;
        
        % Roll moment due to lateral acceleration
        roll_moment = h * F_y;
        
        % Roll dynamics
        omega_roll = omega_roll + (roll_moment / I_x) * dt;
        roll_angle = roll_angle + omega_roll * dt;
        roll_angles(i) = roll_angle;
        
        % Update car visualization with roll angle and position
        if isvalid(car_plot.body)
            update_car_plot_with_path(car_plot, roll_angle, car_position);
        else
            disp('Car body object has been deleted or is invalid.');
            break;
        end
        drawnow;
        
        % Check for flip condition: when the roll angle exceeds a threshold
        if abs(roll_angle) > atan(w / (2 * h))
            disp('Vehicle flips due to high roll angle!');
            break;
        end
        
        pause(0.01); % To simulate real-time behavior
    end
    
    % Display final state
    if abs(roll_angle) <= atan(w / (2 * h))
        disp('Vehicle does not flip.');
    end
end

function car_plot = create_car_plot(w, L, h)
    % Create a 3D plot to visualize the car (a box with 4 wheels)
    
    % Dimensions of the car (half of width and length for easier positioning)
    car_width = w / 2;
    car_length = L / 2;
    car_height = h;
    
    % Define vertices for the car body (rectangle in 3D space)
    X = [-car_length car_length car_length -car_length];
    Y = [-car_width -car_width car_width car_width];
    Z = [0 0 0 0]; % Initial car body lies flat on the ground
    
    % Create the car body as a patch (rectangle)
    car_plot.body = patch('XData', X, 'YData', Y, 'ZData', Z, 'FaceColor', 'b', 'FaceAlpha', 0.7);
    
    hold on;
    
    % Add wheels as circles using the 'line' function
    wheel_radius = 0.2; % Radius of the wheels
    car_plot.wheels = [];
    
    for dx = [-car_length, car_length]
        for dy = [-car_width, car_width]
            % Calculate wheel positions (circles)
            theta = linspace(0, 2*pi, 20);
            wheel_x = wheel_radius * cos(theta) + dx;
            wheel_y = wheel_radius * sin(theta) + dy;
            wheel_z = zeros(size(wheel_x)); % Wheels are on the ground
            
            % Plot each wheel as a line
            h = plot3(wheel_x, wheel_y, wheel_z, 'k', 'LineWidth', 2);
            car_plot.wheels = [car_plot.wheels, h];
        end
    end
    
    % Set 3D axis properties
    axis equal;
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    view(3);
end

function update_car_plot_with_path(car_plot, roll_angle, car_position)
    % Update the car plot according to the current roll angle and position
    
    % Rotation matrix for the roll (rotation about the X-axis)
    R_roll = [1, 0, 0;
              0, cos(roll_angle), -sin(roll_angle);
              0, sin(roll_angle), cos(roll_angle)];
    
    % Get current car body data
    if isvalid(car_plot.body) % Ensure patch object still exists
        XData = get(car_plot.body, 'XData');
        YData = get(car_plot.body, 'YData');
        ZData = get(car_plot.body, 'ZData');
        
        % Combine X, Y, Z into vertices
        vertices = [XData(:)'; YData(:)'; ZData(:)'];
        
        % Apply the roll rotation
        rotated_vertices = R_roll * vertices;
        
        % Shift the rotated vertices to the new position on the path
        rotated_vertices(1, :) = rotated_vertices(1, :) + car_position(1);
        rotated_vertices(2, :) = rotated_vertices(2, :) + car_position(2);
        
        % Ensure the Z-coordinate doesn't push the car underground
        rotated_vertices(3, :) = max(rotated_vertices(3, :), 0);
        
        % Update the car body data with the rotated and translated vertices
        set(car_plot.body, 'XData', rotated_vertices(1, :), ...
                           'YData', rotated_vertices(2, :), ...
                           'ZData', rotated_vertices(3, :));
        
        % Apply the same rotation to the wheels and update their positions
        for i = 1:length(car_plot.wheels)
            wheel = car_plot.wheels(i);
            XData = get(wheel, 'XData');
            YData = get(wheel, 'YData');
            ZData = get(wheel, 'ZData');
            
            vertices = [XData(:)'; YData(:)'; ZData(:)'];
            rotated_vertices = R_roll * vertices;
            
            rotated_vertices(1, :) = rotated_vertices(1, :) + car_position(1);
            rotated_vertices(2, :) = rotated_vertices(2, :) + car_position(2);
            
            % Ensure the wheels stay on or above ground
            rotated_vertices(3, :) = max(rotated_vertices(3, :), 0);
            
            set(wheel, 'XData', reshape(rotated_vertices(1, :), size(XData)), ...
                       'YData', reshape(rotated_vertices(2, :), size(YData)), ...
                       'ZData', reshape(rotated_vertices(3, :), size(ZData)));
        end
    else
        disp('Car body object invalid or deleted during plot update.');
    end
end
