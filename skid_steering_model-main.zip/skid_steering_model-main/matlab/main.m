

clc
%% Load parameters
maxX = 6;
t_s = 0.001;
CPV = 7;
parameters


%% Run simulator
simulator

maxX = floor(maxX * 100) / 100;
fText = sprintf('maxX: %d',maxX); % Outputs 3.15
disp(fText)

kM = k;
RUN_ANIMATION = 1;
%% Run animation
if(RUN_ANIMATION == 1)
    animation_3d_noflip
elseif(RUN_ANIMATION == 2)
    animation_2d
end
