%% Parameters
flip_k = 500; % Example index where the flip occurs
width_wheel = 0.1; % Example width of the wheel
r = 0.5; % Example radius of the wheel
size_body = [1; 1; 0.5]; % Example size of the body
ws = [-20 20 -20 20 -0.1 2] + [-5 5 -5 5 0 0]*0; %workspace size


% Define other parameters as necessary
SPEED = 1; % Example speed factor
SHOW_FORCES = 1; % Example flag to show forces
size_force = 0.5; % Example size of force vectors

%% Initialization
H0 = eye(4);
H_cm = eye(4);
H_w10 = [eye(3), [1; 0; -0.5]; 0 0 0 1];
H_w20 = H_w10; % Define similarly
H_w30 = H_w10; % Define similarly
H_w40 = H_w10; % Define similarly




%Plot CM
cm_rot = H_body(1:3,1:3)*CM;
h_cm1 = plot3(x(1),y(1),cm_rot(3),'ko','MarkerSize',8,'LineWidth',2);
h_cm2 = plot3(x(1),y(1),cm_rot(3),'k+','MarkerSize',5,'LineWidth',2);

%Plot trajectory
h_traj = plot3(x(1),y(1),0,'b-','LineWidth',3);

%Plot trajectory - geometric center
theta_cm = atan2(CM(2),CM(1));
h_traj_center = plot3(x(1)-norm(CM(1:2))*cos(theta_cm+psi(1)),y(1)-norm(CM(1:2))*sin(theta_cm+psi(1)),0,'r-','LineWidth',3);

%Plot time
h_time = text(ws(2),ws(3),ws(6),sprintf('T_{sim}: %.2f',t(1)));
% Initialize handles for the body and wheels
h_w1 = plot_cylinder(H0 * H_w10, width_wheel, r, [0.5 0.5 0.5],'-');
h_w2 = plot_cylinder(H0 * H_w20, width_wheel, r, [0.5 0.5 0.5],'-');
h_w3 = plot_cylinder(H0 * H_w30, width_wheel, r, [0.5 0.5 0.5],'-');
h_w4 = plot_cylinder(H0 * H_w40, width_wheel, r, [0.5 0.5 0.5],'-');

h_body = plot_block(H0 * eye(4) * H_cm, size_body, [0 0 0] + 0.5, 0.8, '-');

% Initialize other handles (e.g., for trajectory, CM, forces)
% ...

%% Animation Loop
k = 1;
tic

while(k < length(t))
    % Ensure indices are within bounds
    if k > length(x) || k > length(y) || k > length(psi)
        error('Index k exceeds the length of position or angle arrays.');
    end
    
    % Body
    H_body = [Rot('z', psi(k)), [x(k); y(k); r]; 0 0 0 1];
    
    % Check for flip and update visualization
    if k >= flip_k
        % Adjust the body and wheels for the flip visualization
        % Example flip visualization
        % Rotate the body by 180 degrees around x-axis to simulate a flip
        H_body(1:3, 1:3) = Rot('x', pi) * H_body(1:3, 1:3);
        % Move the body up to simulate flipping
        H_body(1:3, 4) = H_body(1:3, 4) + [0; 0; 0.2];
    end
    
    % Update body
    set_block(H0 * H_body * H_cm, h_body, size_body);
    
    % Update wheels
    % Wheel 1
    H_w1 = H_body * H_cm * H_w10;
    H_w1(1:3,1:3) = H_w1(1:3,1:3) * Rot('z', -wheels(1, k));
    update_cylinder(h_w1, H_w1,width_wheel);
    
    % Wheel 2
    H_w2 = H_body * H_cm * H_w20;
    H_w2(1:3,1:3) = H_w2(1:3,1:3) * Rot('z', -wheels(2, k));
    update_cylinder(h_w2, H_w2,width_wheel);
    
    % Wheel 3
    H_w3 = H_body * H_cm * H_w30;
    H_w3(1:3,1:3) = H_w3(1:3,1:3) * Rot('z', -wheels(3, k));
    update_cylinder(h_w3, H_w3,width_wheel);
    
    % Wheel 4
    H_w4 = H_body * H_cm * H_w40;
    H_w4(1:3,1:3) = H_w4(1:3,1:3) * Rot('z', -wheels(4, k));
    update_cylinder(h_w4, H_w4,width_wheel);
    
    % Trajectory
    traj_plot = [x(1:k); y(1:k); r*ones(1,k)*0; ones(1,k)];
    traj_plot = H0 * traj_plot;
    set(h_traj, 'XData', traj_plot(1,:), 'YData', traj_plot(2,:), 'ZData', traj_plot(3,:));
    
    % CM
    set(h_cm1, 'XData', x(k), 'YData', y(k));
    set(h_cm2, 'XData', x(k), 'YData', y(k));

    traj_plot = [x(1:k) - norm(CM(1:2)) * cos(theta_cm + psi(1:k)); 
                 y(1:k) - norm(CM(1:2)) * sin(theta_cm + psi(1:k)); 
                 r * ones(1, k) * 0; 
                 ones(1, k)];
    traj_plot = H0 * traj_plot;
    set(h_traj_center, 'XData', traj_plot(1,:), 'YData', traj_plot(2,:), 'ZData', traj_plot(3,:));
    
    % Time
    h_time.String = sprintf('T_{sim}: %.2f', t(k));
    
    if (SHOW_FORCES == 1)
        % Force
        H_body_in_cm = H_body * H_cm;
        set(h_force, 'XData', H_body(1,4), 'YData', H_body(2,4), 'UData', size_force * F_tot_log_w(1,k), 'VData', size_force * F_tot_log_w(2,k));
        
        set(h_force1, 'XData', H_w1(1,4), 'YData', H_w1(2,4), 'UData', size_force * F1_log_w(1,k), 'VData', size_force * F1_log_w(2,k));
        set(h_force2, 'XData', H_w2(1,4), 'YData', H_w2(2,4), 'UData', size_force * F2_log_w(1,k), 'VData', size_force * F2_log_w(2,k));
        set(h_force3, 'XData', H_w3(1,4), 'YData', H_w3(2,4), 'UData', size_force * F3_log_w(1,k), 'VData', size_force * F3_log_w(2,k));
        set(h_force4, 'XData', H_w4(1,4), 'YData', H_w4(2,4), 'UData', size_force * F4_log_w(1,k), 'VData', size_force * F4_log_w(2,k));
    end
    
    drawnow

    % Control simulation time
    k = find(t > toc * SPEED, 1);
end

%% Supporting Functions

function h = plot_cylinder(H, width, radius, color,linestyle)
    [X, Y, Z] = cylinder(radius);
    Z = Z * width - width / 2;  % Adjust cylinder height
    % Apply the homogeneous transformation to the cylinder
    X = H(1,1) * X + H(1,4);
    Y = H(2,1) * Y + H(2,4);
    Z = H(3,1) * Z + H(3,4);
    % Plot the cylinder
    h = patch(X, Y, Z, color, ...
            'EdgeColor', 'none', 'LineStyle', linestyle);
end

function update_cylinder(h, H, width_wheel)
    [X, Y, Z] = cylinder(); % Default size (can be parameterized if needed)
    Z = Z * width_wheel - width_wheel / 2; % Adjust cylinder height
    % Apply the homogeneous transformation to the cylinder
    X = H(1,1) * X + H(1,4);
    Y = H(2,1) * Y + H(2,4);
    Z = H(3,1) * Z + H(3,4);
    set(h, 'XData', X, 'YData', Y, 'ZData', Z);
end

